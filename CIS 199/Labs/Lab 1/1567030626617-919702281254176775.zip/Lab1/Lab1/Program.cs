﻿//Grading ID: J2089
//CIS 199-01
//Lab 1
//Due:9/1/2019
//First lab 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Grading ID:  J2089");
            WriteLine("Hobies:        Reading and Shopping");
            WriteLine("Fovorite Book:  Harry Potter");
            WriteLine("Favorite Movie: Titanic");
            
        }
    }
}
